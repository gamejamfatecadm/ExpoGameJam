<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Termos e Condições</title>

  <style>
    @import url("https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;600&display=swap");

    :root {
      --primary-clr: #6c00f9;
      --white: #fff;
      --text-clr: #464646;
      --tabs-list-bg-clr: #dfc8fd;
      --btn-hvr: #4e03b0;
    }

    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      list-style: none;
      font-family: "Open Sans", sans-serif;
    }

    body {
      background: var(--primary-clr);
      font-size: 12px;
      color: var(--text-clr);
    }

    .flex_align_justify {
      display: flex;
      align-items: center;
      justify-content: center;
    }

    .wrapper {
      min-height: 100vh;
      padding: 0 20px;
    }

    .tc_wrap {
      width: 700px;
      max-width: 100%;
      height: 450px;
      background: var(--white);
      display: flex;
      border-radius: 3px;
      overflow: hidden;
    }

    .tc_wrap .tabs_list {
      width: 200px;
      background: var(--tabs-list-bg-clr);
      height: 100%;
    }

    .tc_wrap .tabs_content {
      width: calc(100% - 200px);
      padding: 0 10px 0 20px;
      height: 100%;
    }

    .tc_wrap .tabs_content .tab_head,
    .tc_wrap .tabs_content .tab_foot {
      color: var(--primary-clr);
      padding: 25px 0;
      height: 70px;
    }

    .tc_wrap .tabs_content .tab_head {
      text-align: center;
    }

    .tc_wrap .tabs_content .tab_body {
      height: calc(100% - 140px);
      overflow: auto;
    }

    .tc_wrap .tabs_list ul {
      padding: 70px 20px;
      text-align: right;
    }

    .tc_wrap .tabs_list ul li {
      padding: 10px 0;
      position: relative;
      margin-bottom: 3px;
      cursor: pointer;
      font-weight: bold;
      transition: all 0.5s ease;
    }

    .tc_wrap .tabs_list ul li:before {
      content: "";
      position: absolute;
      top: 0;
      right: -20px;
      width: 2px;
      height: 100%;
      background: var(--primary-clr);
      opacity: 0;
      transition: all 0.5s ease;
    }

    .tc_wrap .tabs_list ul li.active,
    .tc_wrap .tabs_list ul li:hover {
      color: var(--primary-clr);
    }

    .tc_wrap .tabs_list ul li.active:before {
      opacity: 1;
    }

    .tc_wrap .tabs_content .tab_body .tab_item h3 {
      padding-top: 10px;
      margin-bottom: 10px;
      color: var(--primary-clr);
    }

    .tc_wrap .tabs_content .tab_body .tab_item p {
      margin-bottom: 20px;
    }

    .tc_wrap .tabs_content .tab_body .tab_item {
      display: none;
    }

    .tc_wrap .tabs_content .tab_body .tab_item.active {
      display: block !important;
    }

    .tc_wrap .tabs_content .tab_foot button {
      width: 125px;
      padding: 5px 10px;
      background: transparent;
      border: 1px solid;
      border-radius: 25px;
      cursor: pointer;
      transition: all 0.5s ease;
    }

    .tc_wrap .tabs_content .tab_foot button.decline {
      margin-right: 15px;
      border-color: var(--tabs-list-bg-clr);
      color: var(--tabs-list-bg-clr);
    }

    .tc_wrap .tabs_content .tab_foot button.agree {
      background: var(--primary-clr);
      border-color: var(--primary-clr);
      color: var(--white);
    }

    .tc_wrap .tabs_content .tab_foot button.decline:hover {
      background: var(--tabs-list-bg-clr);
      color: var(--white);
    }

    .tc_wrap .tabs_content .tab_foot button.agree:hover {
      background: var(--btn-hvr);
      border-color: var(--btn-hvr);
    }
  </style>
</head>

<body>

<div class="wrapper flex_align_justify">
  <div class="tc_wrap">
    <div class="tabs_list">
      <ul>
        <li data-tc="tab_item_1" class="active">Termos de Uso</li>
        <li data-tc="tab_item_2">Política de Privacidade</li>
        <li data-tc="tab_item_3">FAQ - Perguntas Frequentes</li>
        <li data-tc="tab_item_4">Termination clause</li>
        <li data-tc="tab_item_5">Governing law</li>
      </ul>
    </div>

    <div class="tabs_content">
      <div class="tab_head">
        <h2>Termos e Condições</h2>
      </div>

      <div class="tab_body">

        <div class="tab_item tab_item_1 active">
          <h3>Termos de Uso</h3>
          <p>Última atualização: 19/11/25 <br/>

Bem-vindo ao Portal Game Jam – SIJA FATEC São Sebastião.
Bem-vindo ao Portal Game Jam – SIJA FATEC São Sebastião.
Ao acessar este site, você concorda com os presentes Termos de Uso. Caso não concorde com algum dos termos, pedimos que não utilize o portal.

1. Finalidade do Portal

O Portal Game Jam tem como objetivo disponibilizar os jogos desenvolvidos por alunos da FATEC São Sebastião durante as atividades da Expo Game Jam, promovendo aprendizado, inovação e divulgação dos projetos acadêmicos.

2. Uso do Conteúdo

Todo o conteúdo disponível no portal (textos, imagens, jogos, descrições e materiais associados) é fornecido exclusivamente para fins educacionais e demonstrativos.

O usuário se compromete a:

não copiar, distribuir ou reutilizar o conteúdo sem autorização dos autores;

não tentar modificar arquivos ou sistemas do portal;

não realizar atos que possam afetar o funcionamento do site.

3. Propriedade Intelectual

Os jogos e materiais exibidos no portal são de propriedade de seus respectivos autores (alunos desenvolvedores).
A FATEC São Sebastião exibe o conteúdo apenas para fins acadêmicos.

4. Responsabilidades do Usuário

O usuário se compromete a utilizar o portal de forma responsável, não praticando atos que prejudiquem sua operação ou que violem leis ou direitos de terceiros.

5. Ausência de Garantias

O portal é disponibilizado “no estado em que se encontra”, podendo conter erros, indisponibilidades temporárias ou ajustes em desenvolvimento.
A FATEC não garante funcionamento contínuo, desempenho específico ou ausência total de falhas.

6. Links Externos

O portal pode conter links externos para páginas de terceiros.
A FATEC São Sebastião não se responsabiliza pelo conteúdo, práticas ou políticas de privacidade desses sites.

7. Alterações nos Termos

Estes Termos de Uso podem ser atualizados a qualquer momento, sem aviso prévio. Recomendamos que o usuário consulte periodicamente esta página.

8. Contato

Para dúvidas ou solicitações relacionadas ao portal, entre em contato com a instituição responsável.</p>
        </div>

        <div class="tab_item tab_item_2">
          <h3>Política de Privacidade</h3>
          <p>Última atualização: 19/11/25

A privacidade dos visitantes é importante para nós.
Esta Política de Privacidade explica como tratamos as informações quando você utiliza o Portal Game Jam – SIJA FATEC São Sebastião.

1. Coleta de Dados

O portal não coleta nenhum dado pessoal dos visitantes.
Não solicitamos:

nome

e-mail

telefone

documentos

localização

qualquer outro dado sensível

Também não coletamos informações automaticamente, como logs detalhados, identificadores ou dados de navegação.

2. Cookies

O portal não utiliza cookies, rastreadores ou ferramentas de análise de tráfego.

3. Conteúdo Externo

Alguns jogos podem ser incorporados (embed, iframe) ou disponibilizados para download.
Esses conteúdos podem, eventualmente, ser provenientes de serviços externos utilizados pelos alunos (ex.: itch.io, GitHub Pages etc.).
Nesses casos, cada serviço possui sua própria política de privacidade, sem relação com este portal.

4. Segurança

O portal utiliza práticas básicas de segurança e segue padrões acadêmicos de hospedagem e desenvolvimento.
Como nenhum dado pessoal é coletado, não há armazenamento nem tratamento de informações sensíveis.

5. Alterações nesta Política

Podemos atualizar esta Política de Privacidade a qualquer momento, especialmente caso novas funcionalidades sejam adicionadas ao portal.

6. Contato

Em caso de dúvidas sobre esta política, entre em contato com a instituição responsável pelo projeto.</p>
        </div>

        <div class="tab_item tab_item_3">
          <h3>FAQ - Perguntas Frequentes</h3>
          <p>1. O que é o Portal Game Jam?

O Portal Game Jam é uma plataforma criada para reunir, organizar e exibir os jogos desenvolvidos pelos alunos da FATEC São Sebastião durante a Expo Game Jam. O objetivo é divulgar os projetos, incentivar a inovação e aproximar o ensino superior das escolas parceiras.

2. Quem pode acessar os jogos do portal?

Qualquer pessoa pode visualizar os jogos disponíveis, incluindo estudantes, professores, pais e visitantes interessados. O acesso é totalmente gratuito.

3. Os jogos podem ser baixados?

Atualmente não há opção de download dos jogos.
Todos os jogos do Portal SIJA FATEC São Sebastião são disponibilizados apenas para acesso e utilização dentro da própria plataforma. Caso o recurso de download seja implementado no futuro, essa informação será atualizada oficialmente.

4. O portal coleta dados pessoais?

Não. O Portal Game Jam não coleta nenhum tipo de dado pessoal, não utiliza cookies e não registra informações de navegação. O uso é totalmente seguro e anônimo.

5. Quem desenvolve os jogos exibidos no portal?

Todos os jogos são desenvolvidos por alunos da FATEC São Sebastião como parte da Expo Game Jam, um evento acadêmico voltado à criação de jogos educativos e à aplicação de conceitos de programação, arte e design.

6. Como os jogos são avaliados?

As avaliações são realizadas por estudantes do Ensino Fundamental II das escolas parceiras da FATEC São Sebastião, trazendo uma experiência real de teste e feedback aos desenvolvedores.

7. Posso enviar meu próprio jogo para o portal?

Atualmente, o envio de jogos é limitado aos participantes da Expo Game Jam. No futuro, novas modalidades de participação poderão ser anunciadas.

8. Quem gerencia o portal?

O portal é mantido pela equipe da FATEC São Sebastião, com apoio de professores, alunos e voluntários do projeto SIJA.

9. O portal é gratuito?

Sim. Todo o conteúdo disponibilizado no Portal Game Jam é totalmente gratuito.

10. Como entro em contato em caso de dúvidas?

Você pode entrar em contato diretamente com a FATEC São Sebastião ou com a coordenação da Expo Game Jam por meio dos canais institucionais da faculdade.</p>
        </div>

        <!-- <div class="tab_item tab_item_4">
          <h3>Termination clause</h3>
          <p>Conteúdo...</p>
        </div>

        <div class="tab_item tab_item_5">
          <h3>Governing law</h3>
          <p>Conteúdo...</p>
        </div> -->

      </div>

      <div class="tab_foot flex_align_justify">
        <button class="decline">Recuso</button>
        <button class="agree">Aceito</button>
      </div>
    </div>
  </div>
</div>

<script>
  const tabLists = document.querySelectorAll(".tabs_list ul li");
  const tabItems = document.querySelectorAll(".tab_item");

  tabLists.forEach(list => {
    list.addEventListener("click", () => {
      const tabTarget = list.getAttribute("data-tc");

      tabLists.forEach(li => li.classList.remove("active"));
      list.classList.add("active");

      tabItems.forEach(item => {
        item.classList.contains(tabTarget)
          ? item.classList.add("active")
          : item.classList.remove("active");
      });
    });
  });
</script>

</body>
</html>
