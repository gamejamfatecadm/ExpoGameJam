<?php
$data = json_decode(file_get_contents('data.json'), true);

?>
<?php
include __DIR__ . '/admin/conexao.php';
// --- iniciar $config unificado (DB -> data.json -> defaults)
$config = [];

// tenta carregar configs do DB (se a tabela existir e tiver dados)
if (isset($conn) && $conn) {
    $resCfg = $conn->query("SELECT * FROM configs LIMIT 1");
    if ($resCfg && $rowCfg = $resCfg->fetch_assoc()) {
        // usa os campos do DB como base
        $db = $rowCfg;
    } else {
        $db = [];
    }
} else {
    $db = [];
}

// agora mescla com data.json (você já tem $data = json_decode(...))
$siteFromData = $data['site'] ?? [];

// montar $config final com prioridades:
// 1) valor do DB (quando disponível), 2) valor do data.json, 3) valor padrão
$config = [
    'titulo'      => $db['titulo']       ?? $siteFromData['titulo']       ?? 'Portal Game Jam',
    'logo'        => $db['logo']         ?? 'configs/img/logo/logo branca.svg',
    'background'  => $db['background']   ?? 'configs/img/background/bk.avif',
    'telefone'    => $db['telefone']     ?? $siteFromData['telefone']     ?? '',
    'email'       => $db['email']        ?? $siteFromData['email']        ?? '',
    'endereco'    => $db['endereco']     ?? $siteFromData['endereco']     ?? '',
    'termos'      => $db['termos']       ?? '',
    'politicas'   => $db['politicas']    ?? '',
    // ano_edicao normalmente não existe na tabela; usar do data.json ou ano atual
    'ano_edicao'  => $db['ano_edicao']   ?? ($siteFromData['ano_edicao'] ?? date('Y')),
];

// Segurança extra: garantir chaves definidas (evita notices)
$keys = ['titulo','logo','background','telefone','email','endereco','termos','politicas','ano_edicao'];
foreach ($keys as $k) {
    if (!array_key_exists($k, $config)) $config[$k] = null;
}

$jogos = []; // garante que a variável existe

// Verifica conexão
if (!$conn) {
    die("Erro de conexão com o banco de dados.");
}
// Premiados
$premiados = [];

$queryPremiados = $conn->query("
    SELECT * FROM jogos
    WHERE colocacao IS NOT NULL
    ORDER BY colocacao ASC
");
$premiados = $queryPremiados->fetch_all(MYSQLI_ASSOC);

// Busca todos os jogos
$query = $conn->query("SELECT * FROM jogos ORDER BY id DESC");

if ($query) {
    $jogos = $query->fetch_all(MYSQLI_ASSOC);
} else {
    $jogos = []; // evita erros se a query falhar
}
?>

<?php



?>


<!DOCTYPE html>
<html lang="pt-br">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <?= htmlspecialchars($config['titulo'] ?? 'Portal Game Jam') ?>


  <!-- ==================== FAVICON ==================== -->
  <link rel="shortcut icon" href="configs/img/logo/logo branca.png" type="image/svg+xml">

  <!-- ==================== FONTES ==================== -->
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;700;800;900&display=swap" rel="stylesheet">

  <!--BOX ICONS-->
  <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>

  <!-- ==================== ESTILO PRINCIPAL ==================== -->
  <link rel="stylesheet" href="css/style.css">

  
</head>

<body>

  <!-- ============================================================= -->
  <!-- ==================== CABEÇALHO / NAVBAR ==================== -->
  <!-- ============================================================= -->
  <header class="header">
    <section class="flex">
      <a href="#home" class="logo">
        <img src="configs/img/logo/logo branca.svg" alt="Logo <?= htmlspecialchars($data['site']['titulo']) ?>">
      </a>

      <nav class="navbar">
        <a href="#home">home</a>
        <a href="#premiados">premiados</a>
        <a href="#jogos">jogos</a>
        <a href="#contato">contato</a>
      </nav>
      <a href="sobre.php" target="_blank" class="btn">SOBRE NÓS</a>
      <div id="menu-btn" class="fa fa-bars-staggered"></div>
    </section>
  </header>

  <!-- ============================================================ -->
  <!-- ==================== SEÇÃO PRINCIPAL / HERO ================ -->
  <!-- ============================================================ -->
  <section class="home" id="home">
    <div class="hero-bg-text">
      <img src="configs/img/background/bk2.png" alt="<?= htmlspecialchars($data['site']['titulo']) ?>" class="hero-title-img">
    </div>

    <div class="hero-character">
      <img src="configs/img/background/personagem.png" alt="Personagem do jogo">
    </div>

    <div class="content">
      <a href="#premiados" class="btn-scroll">
        <i class="fas fa-angles-down"></i>
      </a>
    </div>
  </section>

  <!-- ========================================================== -->
  <!-- ==================== SEÇÃO PREMIADOS ===================== -->
  <!-- ========================================================== -->
 <section id="premiados" class="slider-container">
  <h1 class="heading"><span>Premiados</span> <?= htmlspecialchars($config['ano_edicao'] ?? date('Y')) ?></h1>

  <div class="slider-images">

    <?php
      // Mapeia premiados pela colocação
      $premiadosMap = [];
      foreach ($premiados as $p) {
          $premiadosMap[(int)$p['colocacao']] = $p;
      }

      // Ordem oficial desejada (centraliza 1º)
      $ordem = [2, 1, 3];

      foreach ($ordem as $colocacao):
          if (isset($premiadosMap[$colocacao])):
              $p = $premiadosMap[$colocacao];
    ?>

      <div class="slider-img">
        <img src="configs/img/jogos/<?= htmlspecialchars($p['imagem']) ?>" 
             alt="<?= htmlspecialchars($p['titulo']) ?>">

        <h1><?= (int)$p['colocacao'] ?>º</h1>

        <div class="details">
          <h2><?= htmlspecialchars($p['titulo']) ?></h2>
          <p><?= nl2br(htmlspecialchars($p['descricao'])) ?></p>
          <a href="<?= htmlspecialchars($p['link']) ?>" target="_blank">Abrir jogo</a>
        </div>
      </div>

    <?php
          endif;
      endforeach;
    ?>

  </div>
</section>




  <!-- ========================================================== -->
  <!-- ==================== SEÇÃO JOGOS ========================= -->
  <!-- ========================================================== -->
  <section id="jogos" class="jogos">
    <h1 class="heading"><span>Todos</span> Jogos</h1>

   <div class="box-container">
<?php foreach ($jogos as $jogo): ?>
    <?php if ($jogo['colocacao'] === null): ?>
        <a href="<?= htmlspecialchars($jogo['link']) ?>" target="_blank" class="box">
            <img src="configs/img/jogos/<?= htmlspecialchars($jogo['imagem']) ?>" 
                 alt="<?= htmlspecialchars($jogo['titulo']) ?>">
        </a>
    <?php endif; ?>
<?php endforeach; ?>
</div>


    

    </div>
  </section>

  <!-- ========================================================== -->
  <!-- ==================== SEÇÃO CONTATO ======================= -->
  <!-- ========================================================== -->
  <section class="contact section" id="contato">
    <h1 class="heading"><span>Informações de</span> contato</h1>

    <div class="contact_container">
      <div class="contact_content">
        <div class="contact_box">
          <i class='bx bx-home contact_icon'></i>
          <h3 class="contact_title">Localização</h3>
     <span class="contact_description"><?= htmlspecialchars($config['endereco']) ?></span>
        </div>

        <div class="contact_box">
          <i class='bx bx-phone contact_icon'></i>
          <h3 class="contact_title">Contato</h3>
         <span class="contact_description"><?= htmlspecialchars($config['telefone']) ?></span>
        </div>

        <div class="contact_box">
          <i class='bx bx-envelope contact_icon'></i>
          <h3 class="contact_title">E-mail</h3>
          <span class="contact_description"><?= htmlspecialchars($config['email']) ?></span>
        </div>
      </div>

      <form action="https://formsubmit.co/<?= htmlspecialchars($config['email']) ?>" method="POST" target="_blank" class="contact_form">

        <input type="hidden" name="_captcha" value="false">
        <input type="hidden" name="_next" value="obrigado.html">

        <div class="contact_inputs">
          <input type="text" name="name" placeholder="Seu nome" class="contact_input" required>
          <input type="email" name="email" placeholder="Seu e-mail" class="contact_input" required>
        </div>

        <div class="contact_inputs">
          <input type="text" name="subject" placeholder="Assunto" class="contact_input" required>
          <input type="tel" name="phone" placeholder="Telefone" class="contact_input">
        </div>

        <textarea name="message" rows="7" placeholder="Mensagem" class="contact_input" required></textarea>
        <input type="submit" value="Enviar mensagem" class="contact_button">
      </form>
    </div>
  </section>

  <!-- ========================================================== -->
  <!-- ==================== RODAPÉ ============================== -->
  <!-- ========================================================== -->
  <footer class="footer">

  <div class="box-container">

    <div class="box">
      <h3>links rápidos</h3>
      <a class="link" href="#home">home</a>
      <a class="link" href="#premiados">jogos premiados</a>
      <a class="link" href="#jogos">jogos</a>
      <a class="link" href="#contato">contato</a>
      <a class="link" href="login.php">Fazer Login</a>
      <a class="link" href="sobre.php" target="_blank">Sobre nós</a>
    </div>

    <div class="box">
      <h3>Saiba mais</h3>
      <p>"<?= htmlspecialchars($data['site']['descricao']) ?>"</p>
      <div class="share-links">
        <a href="#" class="fab fa-discord"></a>
        <a href="#" class="fab fa-youtube"></a>
        <a href="#" class="fab fa-linkedin"></a>
        <a href="#" class="fab fa-github"></a>
      </div>
    </div>

    <div class="box">
      <h3>Links Extras</h3>
      <a class="link" href="faq.php" target="_blank">Perguntas frequentes</a>
      <a class="link" href="termos.php" target="_blank">Termos de uso</a>
      <a class="link" href="privacidade.php" target="_blank">Política de Privacidade</a>
      <a class="link" href="#">Novas Atualizações</a>
    </div>

  </div>

  <div class="credit">
    <p>created by <span>Fatecanos de São Sebastião</span></p>
    <p>Todos os direitos reservados | @<?= date('Y') ?> <?= htmlspecialchars($config['titulo']) ?></p>
  </div>

</footer>



  <!-- SCRIPTS -->
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <script src="js/script.js"></script>
  <script>
    jQuery(function ($) {
      $(".slider-img").on("mouseenter", function () {
        $(".slider-img").removeClass("active");
        $(this).addClass("active");
      });
      $(".slider-images").on("mouseleave", function () {
        $(".slider-img").removeClass("active");
      });
    });
  </script>
</body>
</html>
