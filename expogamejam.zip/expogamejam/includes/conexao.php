<?php
$host = 'sql210.infinityfree.com';
$user = 'if0_40451414';
$pass = '997378598mn'; // sua senha do banco
$db   = 'if0_40451414_expogamejam';

$conn = new mysqli($host, $user, $pass, $db);

// Verifica se houve erro na conexão
if ($conn->connect_error) {
    die("Erro na conexão: " . $conn->connect_error);
}

// Define charset UTF-8 para evitar problemas com acentos
$conn->set_charset('utf8mb4');
?>
