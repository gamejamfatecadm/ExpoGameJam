<?php
include __DIR__ . '/admin/conexao.php';

// Garante que a conexão está ok
if (!$conn) {
    die("Erro de conexão com o banco de dados.");
}
$conn->set_charset('utf8mb4');
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="utf-8">
  <title>Painel Administrativo</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <div class="container">
    <h1>Painel Administrativo</h1>
    <p>Escolha o módulo:</p>

    <div class="menu-grid">
      <a class="card" href="jogos/jogos.php">
        <h3>🎮 Gerenciar Jogos</h3>
        <p>Adicionar, editar, excluir jogos (título, descrição, imagem, link).</p>
      </a>

      <a class="card" href="configs/configs.php">
        <h3>⚙️ Configurações do Site</h3>
        <p>Editar logo, telefone, email, endereço, termos e políticas.</p>
      </a>
    </div>

    <p><a class="btn" href="../index.php" target="_blank">Ver site público</a></p>
  </div>
</body>
</html>
