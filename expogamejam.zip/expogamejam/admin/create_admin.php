<?php
include('conexao.php');

// Dados do admin
$nome = "Administrador";
$email = "teste1@gmail.com";
$senha = "1234";

// Gerar hash seguro
$hash = password_hash($senha, PASSWORD_DEFAULT);

// Inserir no banco
$sql = "INSERT INTO usuarios (nome, email, senha_hash) VALUES (?, ?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("sss", $nome, $email, $hash);

if ($stmt->execute()) {
    echo "Usuário admin criado com sucesso!<br>";
    echo "Email: $email<br>";
    echo "Senha: $senha";
} else {
    echo "Erro ao criar admin: " . $stmt->error;
}
?>
