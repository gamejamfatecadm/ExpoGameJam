<?php
// admin/configs/configs_edit.php
include '../conexao.php';

$res = $conn->query("SELECT * FROM configs LIMIT 1");
$config = $res->fetch_assoc();

$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $telefone = trim($_POST['telefone'] ?? '');
  $email = trim($_POST['email'] ?? '');
  $endereco = trim($_POST['endereco'] ?? '');
  $termos = trim($_POST['termos'] ?? '');
  $politicas = trim($_POST['politicas'] ?? '');

  $logoName = $config['logo'] ?? null;

  if (!empty($_FILES['logo']['name']) && $_FILES['logo']['error'] === UPLOAD_ERR_OK) {
    $f = $_FILES['logo'];
    $allowed = ['image/jpeg','image/png','image/webp','image/avif','image/svg+xml'];
    if (!in_array($f['type'], $allowed)) $errors[] = "Formato do logo inválido.";
    if ($f['size'] > 2 * 1024 * 1024) $errors[] = "Logo muito grande (máx 2MB).";

    if (empty($errors)) {
      $ext = pathinfo($f['name'], PATHINFO_EXTENSION);
      $logoName = 'logo_' . time() . '_' . bin2hex(random_bytes(4)) . '.' . $ext;
      $dest = __DIR__ . '/../../configs/img/logo/' . $logoName;
      if (!is_dir(dirname($dest))) mkdir(dirname($dest), 0755, true);
      if (!move_uploaded_file($f['tmp_name'], $dest)) $errors[] = "Erro ao enviar logo.";
      else {
        // remove antigo
        if (!empty($config['logo'])) {
          $old = __DIR__ . '/../../configs/img/logo/' . $config['logo'];
          if (is_file($old)) @unlink($old);
        }
      }
    }
  }

  if (empty($errors)) {
    if ($config) {
      $stmt = $conn->prepare("UPDATE configs SET nome_site=?, logo=?, telefone=?, email=?, endereco=?, termos=?, politicas=? WHERE id=?");
      $stmt->bind_param("sssssssi", $nome_site, $logoName, $telefone, $email, $endereco, $termos, $politicas, $config['id']);
      $stmt->execute();
    } else {
      $stmt = $conn->prepare("INSERT INTO configs (logo, telefone, email, endereco, termos, politicas) VALUES (?, ?, ?, ?, ?, ?, ?)");
      $stmt->bind_param("sssssss", $nome_site, $logoName, $telefone, $email, $endereco, $termos, $politicas);
      $stmt->execute();
    }
    header("Location: configs.php");
    exit;
  }
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="utf-8">
  <title>Editar Configurações</title>
  <link rel="stylesheet" href="../style.css">
</head>
<body>
  <div class="container">
    <h1>Editar Configurações</h1>
    <p><a class="small-link" href="configs.php">← Voltar</a></p>

    <?php if(!empty($errors)): ?>
      <div class="form"><strong>Erros:</strong><ul><?php foreach($errors as $e) echo "<li>".htmlspecialchars($e)."</li>"; ?></ul></div>
    <?php endif; ?>


      <label>Logo atual</label>
      <?php if(!empty($config['logo'])): ?>
        <div><img class="thumb" src="../../configs/img/logo/<?= rawurlencode($config['logo']) ?>" alt=""></div>
      <?php else: ?>
        <div class="note">Nenhum logo definido.</div>
      <?php endif; ?>

      <label>Substituir logo (opcional, png/jpg/svg) — máx 2MB</label>
      <input type="file" name="logo" accept="image/*">

      <label>Telefone</label>
      <input type="text" name="telefone" value="<?= htmlspecialchars($config['telefone'] ?? '') ?>">

      <label>Email</label>
      <input type="text" name="email" value="<?= htmlspecialchars($config['email'] ?? '') ?>">

      <label>Endereço</label>
      <input type="text" name="endereco" value="<?= htmlspecialchars($config['endereco'] ?? '') ?>">

      <label>Termos</label>
      <textarea name="termos" rows="4"><?= htmlspecialchars($config['termos'] ?? '') ?></textarea>

      <label>Políticas</label>
      <textarea name="politicas" rows="4"><?= htmlspecialchars($config['politicas'] ?? '') ?></textarea>

      <button class="btn" type="submit">Salvar</button>
    </form>
  </div>
</body>
</html>
