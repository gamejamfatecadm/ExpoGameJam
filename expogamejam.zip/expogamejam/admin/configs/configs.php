<?php
// admin/configs/configs.php
include '../conexao.php';

$res = $conn->query("SELECT * FROM configs LIMIT 1");
$config = $res->fetch_assoc();
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="utf-8">
  <title>Configurações do Site</title>
  <link rel="stylesheet" href="../style.css">
</head>
<body>
  <div class="container">
    <h1>Configurações do Site</h1>
    <p><a class="small-link" href="../painel.php">← Voltar ao painel</a> <a class="btn" href="configs_edit.php">Editar</a></p>

    <table>
      <tr><th>Campo</th><th>Valor</th></tr>
      <tr><td>Logo</td><td>
        <?php if(!empty($config['logo'])): ?>
          <img class="thumb" src="../../configs/img/logo/<?= rawurlencode($config['logo']) ?>" alt="">
        <?php else: ?>—<?php endif; ?>
      </td></tr>
      <tr><td>Telefone</td><td><?= htmlspecialchars($config['telefone'] ?? '') ?></td></tr>
      <tr><td>Email</td><td><?= htmlspecialchars($config['email'] ?? '') ?></td></tr>
      <tr><td>Endereço</td><td><?= nl2br(htmlspecialchars($config['endereco'] ?? '')) ?></td></tr>
      <tr><td>Termos</td><td><?= nl2br(htmlspecialchars($config['termos'] ?? '')) ?></td></tr>
      <tr><td>Políticas</td><td><?= nl2br(htmlspecialchars($config['politicas'] ?? '')) ?></td></tr>
    </table>
  </div>
</body>
</html>
