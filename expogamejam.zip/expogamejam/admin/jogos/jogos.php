<?php
include __DIR__ . '/admin/conexao.php';

// Verifica conexão
if (!$conn) {
    die("Erro de conexão com o banco de dados.");
}
$conn->set_charset('utf8mb4');
?>
<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// --- Deletar jogo se solicitado
if (isset($_GET['delete'])) {
    $idDel = intval($_GET['delete']);
    // Buscar nome da imagem para excluir
    $stmt = $conn->prepare("SELECT imagem FROM jogos WHERE id = ?");
    $stmt->bind_param("i", $idDel);
    $stmt->execute();
    $res = $stmt->get_result();
    $jogoDel = $res->fetch_assoc();
    $stmt->close();

    if ($jogoDel) {
        $imgPath = __DIR__ . '/../configs/img/jogos/' . $jogoDel['imagem'];
        if (file_exists($imgPath)) unlink($imgPath);
        // Deleta do banco
        $stmt = $conn->prepare("DELETE FROM jogos WHERE id = ?");
        $stmt->bind_param("i", $idDel);
        $stmt->execute();
        $stmt->close();
        header("Location: jogos.php");
        exit;
    }
}

// --- Buscar todos os jogos
$result = $conn->query("SELECT * FROM jogos ORDER BY id DESC");
$jogos = $result ? $result->fetch_all(MYSQLI_ASSOC) : [];
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="utf-8">
<title>Gerenciar Jogos</title>
<link rel="stylesheet" href="../style.css">
</head>
<body>

<div class="container">
    <h1>Todos os Jogos</h1>
    <p><a class="btn" href="jogos_add.php">+ Adicionar Novo Jogo</a></p>

    <?php if(empty($jogos)): ?>
        <p>Nenhum jogo cadastrado.</p>
    <?php else: ?>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Título</th>
                    <th>Imagem</th>
                    <th>Categoria</th>
                    <th>Gênero</th>
                    <th>Colocação</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($jogos as $j): ?>
                    <tr>
                        <td><?= htmlspecialchars($j['id']) ?></td>
                        <td><?= htmlspecialchars($j['titulo']) ?></td>
                        <td>
                            <?php if($j['imagem'] && file_exists(__DIR__ . '/../configs/img/jogos/' . $j['imagem'])): ?>
                                <img src="../configs/img/jogos/<?= htmlspecialchars($j['imagem']) ?>" alt="Imagem" style="max-width:80px;">
                            <?php else: ?>
                                ---
                            <?php endif; ?>
                        </td>
                        <td><?= htmlspecialchars($j['categoria_matematica']) ?></td>
                        <td><?= htmlspecialchars($j['genero']) ?></td>
                        <td><?= $j['colocacao'] !== null ? $j['colocacao'] . 'º' : '-' ?></td>
                        <td>
                            <a class="btn" href="jogos_edit.php?id=<?= $j['id'] ?>">Editar</a>
                            <a class="btn btn-danger" href="jogos.php?delete=<?= $j['id'] ?>" onclick="return confirm('Deseja realmente excluir este jogo?');">Excluir</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
</div>

</body>
</html>
