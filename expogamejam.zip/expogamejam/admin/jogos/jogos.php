<?php
// admin/jogos/jogos.php
include '../conexao.php';

$res = $conn->query("SELECT * FROM jogos ORDER BY id DESC");
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="utf-8">
  <title>Gerenciar Jogos</title>
  <link rel="stylesheet" href="../style.css">
</head>
<body>
  <div class="container">
    <h1>Gerenciar Jogos</h1>
    <p><a class="btn" href="jogos_add.php">+ Adicionar Novo Jogo</a> <a class="small-link" href="../painel.php">← Voltar ao painel</a></p>

    <table>
      <tr><th>ID</th><th>Título</th><th>Imagem</th><th>Descrição</th><th>Link</th><th>Colocação</th><th>Ações</th></tr>

      <?php while($row = $res->fetch_assoc()): ?>
      <tr>
        <td><?= $row['id'] ?></td>
        <td><?= htmlspecialchars($row['titulo']) ?></td>
        <td><img class="thumb" src="../../configs/img/jogos/<?= rawurlencode($row['imagem']) ?>" alt="" ></td>
        <td><?= nl2br(htmlspecialchars($row['descricao'])) ?></td>
        <td><a href="<?= htmlspecialchars($row['link']) ?>" target="_blank" class="small-link">Abrir</a></td>
        <td>
  <?= $row['colocacao'] ? $row['colocacao'] . "º" : "-" ?>
</td>

        <td class="actions">
          <a class="small-link" href="jogos_edit.php?id=<?= $row['id'] ?>">Editar</a>
          <a class="small-link" href="jogos_delete.php?id=<?= $row['id'] ?>" onclick="return confirm('Deseja excluir este jogo?')">Excluir</a>
        </td>
      </tr>
      <?php endwhile; ?>
    </table>
  </div>
</body>
</html>
