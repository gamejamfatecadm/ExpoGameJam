<?php
// admin/jogos/jogos_edit.php
include '../conexao.php';

$id = intval($_GET['id'] ?? 0);
$row = null;

// ===============================
// BUSCA O JOGO PARA EDIÇÃO
// ===============================
if ($id > 0) {

    $stmt = $conn->prepare("SELECT id, titulo, descricao, imagem, link, colocacao FROM jogos WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();

    // suporte mesmo sem mysqlnd
    $stmt->bind_result($rid, $rtitulo, $rdescricao, $rimagem, $rlink, $rcolocacao);

    if ($stmt->fetch()) {
        $row = [
            'id'         => $rid,
            'titulo'     => $rtitulo,
            'descricao'  => $rdescricao,
            'imagem'     => $rimagem,
            'link'       => $rlink,
            'colocacao'  => $rcolocacao
        ];
    } else {
        header("Location: jogos.php");
        exit;
    }

    $stmt->close();

} else {
    header("Location: jogos.php");
    exit;
}

// Garante que a chave exista
if (!isset($row['colocacao'])) {
    $row['colocacao'] = null;
}
// Normaliza valor
$coloc = $row['colocacao'] !== null ? (int)$row['colocacao'] : null;


// ===============================
// PROCESSAR ENVIO DO FORM
// ===============================
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $titulo = trim($_POST['titulo'] ?? '');
    $descricao = trim($_POST['descricao'] ?? '');
    $link = trim($_POST['link'] ?? '');

    // premiação
    $colocacao = (isset($_POST['colocacao']) && $_POST['colocacao'] !== '')
        ? intval($_POST['colocacao'])
        : null;

    if ($titulo === '') $errors[] = "Título é obrigatório.";
    if ($link === '')   $errors[] = "Link é obrigatório.";

    $newImageName = $row['imagem']; // default

    // ===============================
    // TRATAMENTO DE IMAGEM
    // ===============================
    if (!empty($_FILES['imagem']['name']) && $_FILES['imagem']['error'] === UPLOAD_ERR_OK) {

        $f = $_FILES['imagem'];
        $allowed = ['image/jpeg','image/png','image/webp','image/gif','image/avif'];

        if (!in_array($f['type'], $allowed)) {
            $errors[] = "Formato de imagem inválido.";
        }

        if ($f['size'] > 5 * 1024 * 1024) {
            $errors[] = "Imagem muito grande (máx 5MB).";
        }

        if (empty($errors)) {
            $ext = pathinfo($f['name'], PATHINFO_EXTENSION);
            $newImageName = time() . '_' . bin2hex(random_bytes(6)) . '.' . $ext;

            $dest = __DIR__ . '/../../configs/img/jogos/' . $newImageName;

            if (!is_dir(dirname($dest))) {
                mkdir(dirname($dest), 0755, true);
            }

            if (!move_uploaded_file($f['tmp_name'], $dest)) {
                $errors[] = "Erro ao enviar nova imagem.";
            } else {
                // remove a antiga
                $old = __DIR__ . '/../../configs/img/jogos/' . $row['imagem'];
                if (is_file($old)) @unlink($old);
            }
        }
    }

    // ===============================
    // SE NÃO HÁ ERROS -> SALVAR
    // ===============================
    if (empty($errors)) {
        $stmt = $conn->prepare("
            UPDATE jogos 
            SET titulo=?, descricao=?, imagem=?, link=?, colocacao=? 
            WHERE id=?
        ");

        // ss ss i  i
        $stmt->bind_param("ssssii",
            $titulo,
            $descricao,
            $newImageName,
            $link,
            $colocacao,
            $id
        );

        $stmt->execute();
        $stmt->close();

        header("Location: jogos.php");
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="utf-8">
    <title>Editar Jogo</title>
    <link rel="stylesheet" href="../style.css">
</head>
<body>
<div class="container">

    <h1>Editar Jogo</h1>
    <p><a class="small-link" href="jogos.php">← Voltar</a></p>

    <?php if(!empty($errors)): ?>
        <div class="form">
            <strong>Erros:</strong>
            <ul>
                <?php foreach($errors as $e): ?>
                    <li><?= htmlspecialchars($e) ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>

    <form class="form" method="post" enctype="multipart/form-data">

        <label>Título</label>
        <input type="text" name="titulo" 
               value="<?= htmlspecialchars($row['titulo']) ?>" required>

        <label>Descrição</label>
        <textarea name="descricao" rows="6"><?= htmlspecialchars($row['descricao']) ?></textarea>

        <label>Imagem atual</label>
        <div>
            <img class="thumb" src="../../configs/img/jogos/<?= rawurlencode($row['imagem']) ?>" alt="">
        </div>

        <label>Substituir imagem (opcional)</label>
        <input type="file" name="imagem" accept="image/*">

        <label>Link</label>
        <input type="url" name="link" value="<?= htmlspecialchars($row['link']) ?>" required>

        <!-- CAMPO DE COLOCAÇÃO / PREMIAÇÃO -->
        <label>Colocação</label>
        <select name="colocacao">
            <option value="" <?= $coloc === null ? 'selected' : '' ?>>Nenhuma (não premiado)</option>
            <option value="1" <?= $coloc === 1 ? 'selected' : '' ?>>1º Lugar</option>
            <option value="2" <?= $coloc === 2 ? 'selected' : '' ?>>2º Lugar</option>
            <option value="3" <?= $coloc === 3 ? 'selected' : '' ?>>3º Lugar</option>
        </select>

        <button class="btn" type="submit">Salvar Alterações</button>
    </form>

</div>
</body>
</html>
