<?php
// admin/jogos/jogos_edit.php
include '../conexao.php';

$id = intval($_GET['id'] ?? 0);
$row = null;

// ===============================
// BUSCA O JOGO PARA EDIÇÃO
// ===============================
if ($id > 0) {

    $stmt = $conn->prepare("
        SELECT id, titulo, descricao, imagem, link, colocacao, categoria_matematica, genero 
        FROM jogos 
        WHERE id = ?
    ");
    $stmt->bind_param("i", $id);
    $stmt->execute();

    // suporte para ambientes sem mysqlnd
    $stmt->bind_result($rid, $rtitulo, $rdescricao, $rimagem, $rlink, $rcolocacao, $rcat_m, $rgenero);

    if ($stmt->fetch()) {
        $row = [
            'id'                   => $rid,
            'titulo'               => $rtitulo,
            'descricao'            => $rdescricao,
            'imagem'               => $rimagem,
            'link'                 => $rlink,
            'colocacao'            => $rcolocacao,
            'categoria_matematica' => $rcat_m,
            'genero'               => $rgenero
        ];
    } else {
        header("Location: jogos.php");
        exit;
    }

    $stmt->close();
} else {
    header("Location: jogos.php");
    exit;
}

// Normalizando valores
$row['colocacao'] = $row['colocacao'] !== null ? (int)$row['colocacao'] : null;
$coloc = $row['colocacao'];
$cat_m = $row['categoria_matematica'] ?? '';
$genero = $row['genero'] ?? '';

// ===============================
// PROCESSAR FORM
// ===============================
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $titulo = trim($_POST['titulo'] ?? '');
    $descricao = trim($_POST['descricao'] ?? '');
    $link = trim($_POST['link'] ?? '');
    $categoria_matematica = trim($_POST['categoria_matematica'] ?? '');
    $genero = trim($_POST['genero'] ?? '');

    // premiação
    $colocacao = ($_POST['colocacao'] !== '') ? intval($_POST['colocacao']) : null;

    if ($titulo === '') $errors[] = "Título é obrigatório.";
    if ($link === '')   $errors[] = "Link é obrigatório.";

    $newImageName = $row['imagem'];

    // ===============================
    // TRATAMENTO DE IMAGEM
    // ===============================
    if (!empty($_FILES['imagem']['name']) && $_FILES['imagem']['error'] === UPLOAD_ERR_OK) {

        $f = $_FILES['imagem'];
        $allowed = ['image/jpeg','image/png','image/webp','image/gif','image/avif'];

        if (!in_array($f['type'], $allowed)) {
            $errors[] = "Formato de imagem inválido.";
        }

        if ($f['size'] > 5 * 1024 * 1024) {
            $errors[] = "Imagem muito grande (máx 5MB).";
        }

        if (empty($errors)) {
            $ext = pathinfo($f['name'], PATHINFO_EXTENSION);
            $newImageName = time() . '_' . bin2hex(random_bytes(6)) . '.' . $ext;

            $dest = __DIR__ . '/../../configs/img/jogos/' . $newImageName;

            if (!is_dir(dirname($dest))) {
                mkdir(dirname($dest), 0755, true);
            }

            if (!move_uploaded_file($f['tmp_name'], $dest)) {
                $errors[] = "Erro ao enviar nova imagem.";
            } else {
                // remove antiga
                $old = __DIR__ . '/../../configs/img/jogos/' . $row['imagem'];
                if (is_file($old)) @unlink($old);
            }
        }
    }

    // ===============================
    // SALVAR NO BANCO
    // ===============================
    if (empty($errors)) {

        $stmt = $conn->prepare("
            UPDATE jogos 
            SET titulo=?, descricao=?, imagem=?, link=?, colocacao=?, categoria_matematica=?, genero=? 
            WHERE id=?
        ");

        $stmt->bind_param(
            "ssssissi",
            $titulo,
            $descricao,
            $newImageName,
            $link,
            $colocacao,
            $categoria_matematica,
            $genero,
            $id
        );

        $stmt->execute();
        $stmt->close();

        header("Location: jogos.php");
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="utf-8">
    <title>Editar Jogo</title>
    <link rel="stylesheet" href="../style.css">
</head>
<body>
<div class="container">

    <h1>Editar Jogo</h1>
    <p><a class="small-link" href="jogos.php">← Voltar</a></p>

    <?php if(!empty($errors)): ?>
        <div class="form">
            <strong>Erros:</strong>
            <ul>
                <?php foreach($errors as $e): ?>
                    <li><?= htmlspecialchars($e) ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>

    <form class="form" method="post" enctype="multipart/form-data">

        <label>Título</label>
        <input type="text" name="titulo"
               value="<?= htmlspecialchars($row['titulo']) ?>" required>

        <label>Descrição</label>
        <textarea name="descricao" rows="6"><?= htmlspecialchars($row['descricao']) ?></textarea>

        <label>Imagem atual</label>
        <div>
            <img class="thumb" src="../../configs/img/jogos/<?= rawurlencode($row['imagem']) ?>" alt="">
        </div>

        <label>Substituir imagem</label>
        <input type="file" name="imagem" accept="image/*">

        <label>Link</label>
        <input type="url" name="link" value="<?= htmlspecialchars($row['link']) ?>" required>

        <!-- CATEGORIA MATEMÁTICA -->
        <label>Categoria Matemática</label>
        <select name="categoria_matematica">
            <option value="">Nenhuma</option>
            <option value="adição"         <?= $cat_m === "adição" ? "selected" : "" ?>>Adição</option>
            <option value="subtração"      <?= $cat_m === "subtração" ? "selected" : "" ?>>Subtração</option>
            <option value="multiplicação"  <?= $cat_m === "multiplicação" ? "selected" : "" ?>>Multiplicação</option>
            <option value="divisão"        <?= $cat_m === "divisão" ? "selected" : "" ?>>Divisão</option>
        </select>

        <!-- GÊNERO -->
        <label>Gênero</label>
        <select name="genero">
            <option value="">Nenhum</option>
            <option value="ação"        <?= $genero === "ação" ? "selected" : "" ?>>Ação</option>
            <option value="rpg"         <?= $genero === "rpg" ? "selected" : "" ?>>RPG</option>
            <option value="cartas"      <?= $genero === "cartas" ? "selected" : "" ?>>Cartas</option>
            <option value="puzzle"      <?= $genero === "puzzle" ? "selected" : "" ?>>Puzzle</option>
            <option value="plataforma"  <?= $genero === "plataforma" ? "selected" : "" ?>>Plataforma</option>
        </select>

        <!-- CAMPO DE COLOCAÇÃO -->
        <label>Colocação</label>
        <select name="colocacao">
            <option value="" <?= $coloc === null ? 'selected' : '' ?>>Nenhuma (não premiado)</option>
            <option value="1" <?= $coloc === 1 ? 'selected' : '' ?>>1º Lugar</option>
            <option value="2" <?= $coloc === 2 ? 'selected' : '' ?>>2º Lugar</option>
            <option value="3" <?= $coloc === 3 ? 'selected' : '' ?>>3º Lugar</option>
        </select>

        <button class="btn" type="submit">Salvar Alterações</button>
    </form>

</div>
</body>
</html>
