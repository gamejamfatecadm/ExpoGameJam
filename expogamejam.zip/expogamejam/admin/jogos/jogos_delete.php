<?php
include __DIR__ . '/admin/conexao.php';

// Garante que a conexão está ok
if (!$conn) {
    die("Erro de conexão com o banco de dados.");
}
$conn->set_charset('utf8mb4');
?>
<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$id = intval($_GET['id'] ?? 0);
if ($id > 0) {
  // recupera arquivo
  $stmt = $conn->prepare("SELECT imagem FROM jogos WHERE id = ?");
  $stmt->bind_param("i", $id);
  $stmt->execute();
  $r = $stmt->get_result()->fetch_assoc();
  if ($r) {
    $file = __DIR__ . '../configs/img/jogos/' . $r['imagem'];
    if (is_file($file)) @unlink($file);
  }

  $stmt = $conn->prepare("DELETE FROM jogos WHERE id = ?");
  $stmt->bind_param("i", $id);
  $stmt->execute();
}

header("Location: jogos.php");
exit;
