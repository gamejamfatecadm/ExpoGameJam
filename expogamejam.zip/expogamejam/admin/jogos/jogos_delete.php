<?php
// admin/jogos/jogos_delete.php
include '../conexao.php';

$id = intval($_GET['id'] ?? 0);
if ($id > 0) {
  // recupera arquivo
  $stmt = $conn->prepare("SELECT imagem FROM jogos WHERE id = ?");
  $stmt->bind_param("i", $id);
  $stmt->execute();
  $r = $stmt->get_result()->fetch_assoc();
  if ($r) {
    $file = __DIR__ . '../configs/img/jogos/' . $r['imagem'];
    if (is_file($file)) @unlink($file);
  }

  $stmt = $conn->prepare("DELETE FROM jogos WHERE id = ?");
  $stmt->bind_param("i", $id);
  $stmt->execute();
}

header("Location: jogos.php");
exit;
