<?php
include '../conexao.php';

$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

  $titulo = trim($_POST['titulo'] ?? '');
  $descricao = trim($_POST['descricao'] ?? '');
  $link = trim($_POST['link'] ?? '');

  $categoria_matematica = $_POST['categoria_matematica'] ?? '';
  $genero = $_POST['genero'] ?? '';

  $colocacao = $_POST['colocacao'] !== '' ? intval($_POST['colocacao']) : null;

  if ($titulo === '') $errors[] = "Título é obrigatório.";
  if ($link === '') $errors[] = "Link é obrigatório.";

  if (!isset($_FILES['imagem']) || $_FILES['imagem']['error'] !== UPLOAD_ERR_OK) {
    $errors[] = "Imagem é obrigatória.";
  } else {
    $f = $_FILES['imagem'];
    $allowed = ['image/jpeg','image/png','image/webp','image/gif','image/avif'];
    if (!in_array($f['type'], $allowed)) $errors[] = "Formato de imagem inválido.";
    if ($f['size'] > 5 * 1024 * 1024) $errors[] = "Imagem muito grande (máx 5MB).";
  }

  if (empty($errors)) {

    $ext = pathinfo($f['name'], PATHINFO_EXTENSION);
    $name = time() . '_' . bin2hex(random_bytes(6)) . '.' . $ext;

    $dest = __DIR__ . '/../../configs/img/jogos/' . $name;
    if (!is_dir(dirname($dest))) mkdir(dirname($dest), 0755, true);

    if (move_uploaded_file($f['tmp_name'], $dest)) {

      $stmt = $conn->prepare("
        INSERT INTO jogos (titulo, descricao, imagem, link, colocacao, categoria_matematica, genero)
        VALUES (?, ?, ?, ?, ?, ?, ?)
      ");
      $stmt->bind_param("ssssiss", 
        $titulo, $descricao, $name, $link, $colocacao, $categoria_matematica, $genero
      );

      $stmt->execute();
      header("Location: jogos.php");
      exit;

    } else {
      $errors[] = "Falha ao mover o arquivo.";
    }
  }
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="utf-8">
  <title>Adicionar Jogo</title>
  <link rel="stylesheet" href="../style.css">
</head>
<body>

<div class="container">
  <h1>Adicionar Novo Jogo</h1>
  <p><a class="small-link" href="jogos.php">← Voltar</a></p>

  <?php if(!empty($errors)): ?>
    <div class="form"><strong>Erros:</strong><ul>
      <?php foreach($errors as $e) echo "<li>".htmlspecialchars($e)."</li>"; ?>
    </ul></div>
  <?php endif; ?>

  <form class="form" method="post" enctype="multipart/form-data">

    <label>Título</label>
    <input type="text" name="titulo" required>

    <label>Descrição</label>
    <textarea name="descricao" rows="5"></textarea>

    <label>Categoria Matemática</label>
    <select name="categoria_matematica" required>
        <option value="">Selecione</option>
        <option value="Adição">Adição</option>
        <option value="Subtração">Subtração</option>
        <option value="Multiplicação">Multiplicação</option>
        <option value="Divisão">Divisão</option>
    </select>

    <label>Gênero do Jogo</label>
    <select name="genero" required>
        <option value="">Selecione</option>
        <option value="RPG">RPG</option>
        <option value="Ação">Ação</option>
        <option value="Puzzle">Puzzle</option>
        <option value="Cartas">Cartas</option>
        <option value="Aventura">Aventura</option>
        <option value="Estratégia">Estratégia</option>
    </select>

    <label>Colocação (opcional)</label>
    <select name="colocacao">
        <option value="">Nenhuma</option>
        <option value="1">1º Lugar</option>
        <option value="2">2º Lugar</option>
        <option value="3">3º Lugar</option>
    </select>

    <label>Imagem</label>
    <input type="file" name="imagem" accept="image/*" required>

    <label>Link</label>
    <input type="url" name="link" required>

    <button class="btn" type="submit">Salvar</button>

  </form>
</div>

</body>
</html>
