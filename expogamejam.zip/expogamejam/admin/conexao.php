<?php
$host = 'sql210.infinityfree.com';
$user = 'if0_40451414';
$pass = '997378598mn';
$db   = 'if0_40451414_expogamejam';

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    die("Erro na conexão: " . $conn->connect_error);
}
$conn->set_charset('utf8mb4');
