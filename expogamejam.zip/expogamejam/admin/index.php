<?php
// Apenas inclui a conexão, caso queira exibir dados futuros
include 'conexao.php';
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
  <title>Painel Administrativo</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>

<h1>Painel Administrativo</h1>
<p>Selecione o que deseja gerenciar:</p>

<div class="menu-grid">

    <a href="jogos/jogos.php" class="card">
        <h2>🎮 Gerenciar Jogos</h2>
        <p>Adicionar, editar, excluir jogos (título, imagem, descrição, link).</p>
    </a>

    <a href="configs/configs.php" class="card">
        <h2>⚙️ Configurações do Site</h2>
        <p>Logo, nome, contatos, textos, políticas, termos.</p>
    </a>


</div>

</body>
</html>

<style>
body {
  font-family: Arial, sans-serif;
  background: #f0f0f0;
  padding: 20px;
}

h1 {
  margin-bottom: 20px;
}

.menu-grid {
  display: flex;
  gap: 20px;
  flex-wrap: wrap;
}

.card {
  background: white;
  padding: 20px;
  width: 300px;
  display: block;
  text-decoration: none;
  color: black;
  border-radius: 10px;
  border: 1px solid #ddd;
  transition: 0.2s;
}

.card:hover {
  background: #eaeaea;
}
</style>
