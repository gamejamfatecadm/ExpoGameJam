<?php
session_start();
if (!isset($_SESSION['logado']) || $_SESSION['logado'] !== true) {
  header("Location: login.php");
  exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $novo = [
    'ano' => $_POST['ano'],
    'premiados' => array_values($_POST['premiados'])
  ];
  file_put_contents('data.json', json_encode($novo, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
  header("Location: adimin.php?salvo=1");
  exit;
}
?>
