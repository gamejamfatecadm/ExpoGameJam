<!DOCTYPE html>
<html lang="pt-br">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>FAQ - Expo Game Jam</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
  <link rel="shortcut icon" href="images/logo branca.svg" type="">

  <style>
    :root {
      --border: 2px solid rgba(255, 255, 255, 0.1);
      --box-shadow: 0 4px 20px rgba(0, 0, 0, 0.2);
      --white: #fff;
      --light-white: #ddd;
      --dark-bg: rgba(0, 0, 0, 0.6);
    }

    body {
      font-family: Arial, Helvetica, sans-serif;
      background-color: #111;
      margin: 0;
      padding: 0;
    }

    /* FAQ Section */
    .faq {
      background: url('images/body-bg.jpg') no-repeat center center/cover;
      background-attachment: fixed;
      padding: 80px 5%;
      color: var(--white);
      min-height: 100vh;
    }

    .faq .heading {
      text-align: center;
      font-size: 3rem;
      margin-bottom: 3rem;
      text-transform: uppercase;
      letter-spacing: 2px;
    }

    .faq .heading span {
      color: #e056fd;
    }

    .faq .box-container {
      display: grid;
      gap: 2rem;
      max-width: 900px;
      margin: 0 auto;
    }

    .faq .box {
      background: var(--dark-bg);
      border: var(--border);
      border-radius: 0.5rem;
      box-shadow: var(--box-shadow);
      padding: 2rem;
      transition: 0.3s;
    }

    .faq .box:hover {
      transform: translateY(-5px);
    }

    .faq .title {
      display: flex;
      justify-content: space-between;
      align-items: center;
      font-size: 1.8rem;
      cursor: pointer;
      user-select: none;
    }

    .faq .title i {
      transition: transform 0.3s ease;
    }

    .faq .content {
      font-size: 1.4rem;
      line-height: 1.6;
      color: var(--light-white);
      max-height: 0;
      overflow: hidden;
      transition: max-height 0.3s ease, padding-top 0.3s ease;
    }

    .faq .content.active {
      max-height: 500px;
      padding-top: 1rem;
    }
  </style>
</head>

<body>

  <!-- FAQ Section -->
  <section class="faq" id="faq">
    <h1 class="heading"><span>P</span>erguntas <span>F</span>requentes</h1>

    <div class="box-container">

      <div class="box">
        <div class="title">
          <h3>Como jogar?</h3>
          <i class="fa fa-plus"></i>
        </div>
        <div class="content">
          Para jogar, acesse o link do jogo e siga as instruções apresentadas na tela.
        </div>
      </div>

      <div class="box">
        <div class="title">
          <h3>Como se inscrever?</h3>
          <i class="fa fa-plus"></i>
        </div>
        <div class="content">
          As inscrições são feitas através do site oficial do evento, na seção “Inscreva-se”.
        </div>
      </div>

      <div class="box">
        <div class="title">
          <h3>Quem pode participar?</h3>
          <i class="fa fa-plus"></i>
        </div>
        <div class="content">
          Todos os alunos da FATEC São Sebastião podem participar do Game Jam!
        </div>
      </div>

      <div class="box">
        <div class="title">
          <h3>Os jogos serão avaliados?</h3>
          <i class="fa fa-plus"></i>
        </div>
        <div class="content">
          Sim! As criações serão avaliadas por alunos e professores convidados durante o evento.
        </div>
      </div>

    </div>
  </section>

  <!-- Script do FAQ -->
  <script>
    const faqBoxes = document.querySelectorAll('.faq .box');

    faqBoxes.forEach(box => {
      const title = box.querySelector('.title');
      const icon = title.querySelector('i');
      const content = box.querySelector('.content');

      title.addEventListener('click', () => {
        const isActive = content.classList.contains('active');

        // Fecha todos os outros
        document.querySelectorAll('.faq .content').forEach(c => c.classList.remove('active'));
        document.querySelectorAll('.faq .title i').forEach(i => i.classList.replace('fa-minus', 'fa-plus'));

        // Alterna o clicado
        if (!isActive) {
          content.classList.add('active');
          icon.classList.replace('fa-plus', 'fa-minus');
        }
      });
    });
  </script>
</body>

</html>