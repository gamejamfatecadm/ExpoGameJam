<!DOCTYPE html>
<html lang="pt-br">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Política de Privacidade - Expo Game Jam</title>
  <link rel="stylesheet" href="privacidade.css">
  <link rel="shortcut icon" href="images/logo branca.svg" type="">
  <style>
    :root {
      --border: 2px solid rgba(255, 255, 255, 0.1);
      --box-shadow: 0 4px 20px rgba(0, 0, 0, 0.2);
      --white: #fff;
      --light-white: #ddd;
      --dark-bg: rgba(0, 0, 0, 0.6);
    }

    body {
      font-family: Arial, Helvetica, sans-serif;
      background-color: #111;
      margin: 0;
      padding: 0;
      color: var(--white);
    }

    /* Seção principal com o background */
    .privacidade {
      background: url('images/body-bg.jpg') no-repeat center center/cover;
      background-attachment: fixed;
      padding: 80px 5%;
      color: var(--white);
      min-height: 100vh;

      display: flex;
      justify-content: center;
      align-items: center;
    }

    /* Container do texto */
    .privacidade-container {
      background: var(--dark-bg);
      border: var(--border);
      box-shadow: var(--box-shadow);
      border-radius: 0.5rem;
      max-width: 900px;
      padding: 40px 50px;
      line-height: 1.8;
      backdrop-filter: blur(4px);
    }

    .privacidade-container h1 {
      text-align: center;
      font-size: 2.8rem;
      margin-bottom: 2rem;
      color: var(--accent);
      text-transform: uppercase;
      letter-spacing: 2px;
    }

    .privacidade-container h2 {
      color: var(--accent);
      font-size: 1.6rem;
      margin-top: 2rem;
    }

    .privacidade-container p,
    .privacidade-container li {
      font-size: 1.2rem;
      color: var(--light-white);
      margin-top: 0.8rem;
    }

    .privacidade-container ul {
      margin-left: 2rem;
    }

    .privacidade-container a {
      color: var(--accent);
      text-decoration: none;
    }

    .privacidade-container a:hover {
      text-decoration: underline;
    }

    .update {
      text-align: right;
      margin-top: 2rem;
      font-size: 1rem;
      color: var(--light-white);
      opacity: 0.8;
    }
  </style>
</head>

<body>

  <!-- Seção Política de Privacidade -->
  <section class="privacidade" id="privacidade">
    <div class="privacidade-container">
      <h1>Política de Privacidade</h1>

      <p>A <strong>Expo GameJam</strong> valoriza a privacidade dos seus usuários e se compromete a proteger suas
        informações pessoais. Esta Política de Privacidade explica como coletamos, usamos e protegemos seus dados ao
        utilizar nosso site.</p>

      <h2>1. Informações Coletadas</h2>
      <p>Podemos coletar informações pessoais como nome e e-mail quando o usuário realiza um cadastro ou entra em
        contato conosco. Também podemos coletar dados automaticamente, como cookies, endereço IP e informações do
        navegador.</p>

      <h2>2. Uso das Informações</h2>
      <p>As informações coletadas são utilizadas para:</p>
      <ul>
        <li>Gerenciar cadastros e acessos ao site;</li>
        <li>Enviar comunicações sobre o evento e atualizações;</li>
        <li>Melhorar a experiência do usuário e o funcionamento do site.</li>
      </ul>

      <h2>3. Armazenamento e Segurança</h2>
      <p>Adotamos medidas de segurança adequadas para proteger os dados pessoais contra acessos não autorizados,
        alterações, divulgação ou destruição indevida.</p>

      <h2>4. Compartilhamento de Dados</h2>
      <p>Não compartilhamos informações pessoais com terceiros, exceto quando exigido por lei ou para cumprir obrigações
        legais.</p>

      <h2>5. Direitos do Usuário</h2>
      <p>Você tem o direito de solicitar o acesso, correção ou exclusão dos seus dados pessoais. Para isso, entre em
        contato pelo e-mail <a href="mailto:gamejamfatec.adm@gmail.com">gamejamfatec.adm@gmail.com</a>.</p>

      <h2>6. Cookies</h2>
      <p>O site pode utilizar cookies para melhorar a navegação e personalizar a experiência do usuário. Você pode
        desativá-los nas configurações do seu navegador.</p>

      <h2>7. Alterações nesta Política</h2>
      <p>Esta política pode ser atualizada periodicamente. Recomendamos revisar esta página para estar ciente de
        possíveis mudanças.</p>

      <h2>8. Contato</h2>
      <p>Em caso de dúvidas sobre esta Política de Privacidade, entre em contato pelo e-mail <a
          href="mailto:gamejamfatec.adm@gmail.com">gamejamfatec.adm@gmail.com</a>.</p>

      <p class="update">Última atualização: 23 de outubro de 2025</p>
    </div>
  </section>

</body>

</html>