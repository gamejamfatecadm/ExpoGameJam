<!DOCTYPE html>
<html lang="pt-br">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Termos de Uso - Expo Game Jam</title>
  <link rel="stylesheet" href="termos.css">
  <link rel="shortcut icon" href="images/logo branca.svg" type="">

  <style>
    :root {
      --border: 2px solid rgba(255, 255, 255, 0.1);
      --box-shadow: 0 4px 20px rgba(0, 0, 0, 0.2);
      --white: #fff;
      --light-white: #ddd;
      --dark-bg: rgba(0, 0, 0, 0.6);
    }

    body {
      font-family: Arial, Helvetica, sans-serif;
      background-color: #111;
      margin: 0;
      padding: 0;
      color: var(--white);
    }

    /* Seção principal com o background */
    .termos {
      background: url('images/body-bg.jpg') no-repeat center center/cover;
      background-attachment: fixed;
      padding: 80px 5%;
      color: var(--white);
      min-height: 100vh;

      display: flex;
      justify-content: center;
      align-items: center;
    }

    /* Container do texto */
    .termos-container {
      background: var(--dark-bg);
      border: var(--border);
      box-shadow: var(--box-shadow);
      border-radius: 0.5rem;
      max-width: 900px;
      padding: 40px 50px;
      line-height: 1.8;
      backdrop-filter: blur(4px);
    }

    .termos-container h1 {
      text-align: center;
      font-size: 2.8rem;
      margin-bottom: 2rem;
      color: var(--accent);
      text-transform: uppercase;
      letter-spacing: 2px;
    }

    .termos-container h2 {
      color: var(--accent);
      font-size: 1.6rem;
      margin-top: 2rem;
    }

    .termos-container p {
      font-size: 1.2rem;
      color: var(--light-white);
      margin-top: 0.8rem;
    }

    .termos-container a {
      color: var(--accent);
      text-decoration: none;
    }

    .termos-container a:hover {
      text-decoration: underline;
    }

    .update {
      text-align: right;
      margin-top: 2rem;
      font-size: 1rem;
      color: var(--light-white);
      opacity: 0.8;
    }
  </style>
</head>

<body>

  <!-- Seção Termos -->
  <section class="termos" id="termos">
    <div class="termos-container">
      <h1>Termos de Uso</h1>
      <p>Bem-vindo ao site <strong>Expo GameJam</strong>! Ao acessar ou utilizar nosso site, você concorda com os
        seguintes termos de uso. Recomendamos a leitura completa deste documento.</p>

      <h2>1. Aceitação dos Termos</h2>
      <p>Ao acessar o site da Expo GameJam, você concorda em cumprir estes Termos de Uso e todas as leis e regulamentos
        aplicáveis. Caso não concorde, pedimos que não utilize o site.</p>

      <h2>2. Uso do Site</h2>
      <p>O conteúdo do site é destinado apenas para fins informativos e de divulgação do evento Expo GameJam. É proibido
        o uso do site para atividades ilegais, difamatórias ou que prejudiquem terceiros.</p>

      <h2>3. Cadastro de Usuário</h2>
      <p>Para participar de determinadas áreas do site, pode ser necessário criar uma conta. Ao se cadastrar, você
        concorda em fornecer informações verdadeiras e manter seus dados atualizados.</p>

      <h2>4. Privacidade</h2>
      <p>As informações pessoais fornecidas pelos usuários são tratadas conforme nossa <a
          href="privacidade.html">Política de Privacidade</a>.</p>

      <h2>5. Alterações dos Termos</h2>
      <p>A Expo GameJam pode alterar estes Termos de Uso a qualquer momento, sem aviso prévio. Recomendamos verificar
        esta página periodicamente.</p>

      <h2>6. Contato</h2>
      <p>Para dúvidas ou solicitações relacionadas a estes termos, entre em contato conosco pelo e-mail <a
          href="mailto:gamejamfatec.adm@gmail.com">gamejamfatec.adm@gmail.com</a>.</p>

      <p class="update">Última atualização: 23 de outubro de 2025</p>
    </div>
  </section>

</body>

</html>