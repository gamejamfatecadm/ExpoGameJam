<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Sobre Nós - Expo Game Jam</title>
  <link rel="stylesheet" href="sobre.css">
  <link rel="shortcut icon" href="images/logo branca.svg" type="">
  <style>
   :root {
      --border: 2px solid rgba(255, 255, 255, 0.1);
      --box-shadow: 0 4px 20px rgba(0, 0, 0, 0.2);
      --white: #fff;
      --light-white: #ddd;
      --dark-bg: rgba(0, 0, 0, 0.6);
    }

body {
  font-family: Arial, Helvetica, sans-serif;
  background-color: #111;
  margin: 0;
  padding: 0;
  color: var(--white);
}

/* Fundo da seção */
.sobre {
  background: url('images/body-bg.jpg') no-repeat center center/cover;
  background-attachment: fixed;
  padding: 80px 5%;
  min-height: 100vh;
  display: flex;
  justify-content: center;
}

.sobre-container {
  max-width: 1100px;
  width: 100%;
  text-align: center;
}

/* Título */
.sobre-container h1 {
  font-size: 2.5rem;
  margin-bottom: 1.5rem;
  color: var(--accent);
}

.sobre-container .intro {
  font-size: 1.2rem;
  color: var(--light-white);
  margin-bottom: 3rem;
  line-height: 1.6;
}

/* Cards */
.membros {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
  gap: 2rem;
  justify-items: center;
}

.membro {
  background: var(--dark-bg);
  border: var(--border);
  border-radius: 0.5rem;
  box-shadow: var(--box-shadow);
  padding: 1.5rem;
  transition: transform 0.3s ease, box-shadow 0.3s ease;
  width: 100%;
  max-width: 320px;
}

.membro:hover {
  transform: translateY(-5px);
  box-shadow: 0 6px 20px rgba(224, 86, 253, 0.3);
}

/* Foto 3x4 sem brilho */
.membro img {
  width: 120px;
  height: 160px;
  border-radius: 0.3rem;
  object-fit: cover;
  margin-bottom: 1rem;
}

.membro h2 {
  font-size: 1.4rem;
  color: var(--accent);
  margin-bottom: 0.3rem;
}

.membro .funcao {
  font-size: 1rem;
  font-weight: bold;
  color: var(--white);
}

.membro .curso {
  font-size: 0.95rem;
  color: var(--light-white);
  margin: 0.5rem 0 1rem;
}

/* Botão CV */
.cv-btn {
  display: inline-block;
  background: var(--accent);
  color: var(--white);
  padding: 0.5rem 1rem;
  border-radius: 0.3rem;
  text-decoration: none;
  transition: background 0.3s, transform 0.2s;
  font-weight: bold;
  font-size: 0.95rem;
}

.cv-btn:hover {
  background: #b947cc;
  transform: translateY(-1px);
}

  </style>
</head>
<body>

  <section class="sobre" id="sobre">
    <div class="sobre-container">
      <h1>Sobre Nós</h1>
      <p class="intro">
        Conheça os responsáveis pelo <strong>Expo GameJam</strong>. Cada membro contribui para tornar o evento uma experiência única e criativa!
      </p>

      <div class="membros">
        <!-- Membro 1 -->
        <div class="membro">
          <img src="images/membro1.jpg" alt="Foto de Igor José Cardoso">
          <h2>Igor José Cardoso</h2>
          <p class="funcao">Desenvolvedor Front-End</p>
          <p class="curso">Cursando Análise e Desenvolvimento de Sistemas</p>
          <a href="curriculos/igor-cardoso.pdf" target="_blank" class="cv-btn">Ver Currículo</a>
        </div>

        <!-- Membro 2 -->
        <div class="membro">
          <img src="images/membro2.jpg" alt="Foto de Maria Fernanda Silva">
          <h2>Maria Fernanda Silva</h2>
          <p class="funcao">Designer e Ilustradora</p>
          <p class="curso">Cursando Design Gráfico</p>
          <a href="curriculos/maria-fernanda.pdf" target="_blank" class="cv-btn">Ver Currículo</a>
        </div>

        <!-- Membro 3 -->
        <div class="membro">
          <img src="images/membro3.jpg" alt="Foto de Lucas Almeida">
          <h2>Lucas Almeida</h2>
          <p class="funcao">Coordenador de Projeto</p>
          <p class="curso">Cursando Jogos Digitais</p>
          <a href="curriculos/lucas-almeida.pdf" target="_blank" class="cv-btn">Ver Currículo</a>
        </div>
      </div>
    </div>
  </section>

</body>
</html>
